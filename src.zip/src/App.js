import "./App.css";
import React, { useState, useEffect } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
// import DatePicker from "react-datepicker";
import Form from "react-bootstrap/Form";

const getLocalStorageItems = () => {
  let newItems = localStorage.getItem("newItems");
  console.log(newItems);
  if (newItems) {
    return JSON.parse(localStorage.getItem("newItems"));
  } else {
    return [];
  }
};

function App() {
  const [show, setShow] = useState(false);
  const [show1, setShow1] = useState(false);
  const [startDate, setStartDate] = useState(null);
  const [note, setNote] = useState("");
  const [addItems, setAddItems] = useState(getLocalStorageItems);
  const [isEditing, setIsEditing] = useState(false);
  const [currentItem, setCurrentItem] = useState({});

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const handleClose1 = () => setShow1(false);
  const handleShow1 = () => setShow1(true);

  const remainigEventDays = (date1) => {
    const eventDay = new Date(date1);
    const today = new Date();
    const perDay = 1000 * 60 * 60 * 24;
    const remainDaysInMilliSeconds = eventDay - today;
    const remainingDays = Math.ceil(remainDaysInMilliSeconds / perDay);
    return remainingDays;
  };

  const handleAddItemsForCards = () => {
    const newItems = [...addItems, {id: addItems.length + 1, date1: startDate, note: note }];
    console.log(newItems)
    setAddItems(newItems);
    handleClose();
    setStartDate(null);
    setNote(null);
  };

  const handleEditInputChange=(e)=> {
    setCurrentItem({ ...currentItem, note: e.target.value });
    console.log(currentItem);
  }
  const handleEditFormSubmit =(e)=> {
    e.preventDefault();
    handleUpdateItem(currentItem.id, currentItem);
  }
  const handleUpdateItem=(id, updatedItem1)=> {
    const updatedItem = addItems.map((item) => {
      return (item.id === id ? updatedItem1 : item);
    });
    console.log(id)
    setIsEditing(false);
    setAddItems(updatedItem);
  }
  
  function handleEditClick(item) {
    setIsEditing(true);
    setCurrentItem({ ...item });
  }

  const handelRemoveItems = (index) => {
    const newItems = [...addItems];
    newItems.splice(index, 1);
    setAddItems(newItems);
  };
  useEffect(() => {
    localStorage.setItem("newItems", JSON.stringify(addItems));
  }, [addItems]);
  return (
    <div className="App">
      <Button variant="primary" onClick={handleShow}>
        Add
      </Button>
      {isEditing ? (
        <Modal show={show1} onHide={handleClose1}>
          <Modal.Header closeButton>
            <Modal.Title>Edit AddItem</Modal.Title>
          </Modal.Header>
          <Form onSubmit={handleEditFormSubmit}>
            <Modal.Body>
              <input
                style={{ marginBottom: "10px" }}
                type="date"
                name="datepic"
                placeholder="DateRange"
                value={startDate}
                minDate={new Date()}
                onChange={(e) => setStartDate(e.target.value)}
              />
              Note:{" "}
              <input
                style={{ borderRadius: "6px" }}
                type="text"
                value={currentItem.note}
                onChange={handleEditInputChange}
              />
            </Modal.Body>
            <Modal.Footer>
              <Button variant="primary">Update</Button>
              <Button onClick={() => setIsEditing(false)}>Cancel</Button>
            </Modal.Footer>
          </Form>
        </Modal>
      ) : (
        <Modal show={show} onHide={handleClose}>
          <Modal.Header closeButton>
            <Modal.Title>Select the Date</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Form.Control
              style={{ marginBottom: "10px" }}
              type="date"
              name="datepic"
              placeholder="DateRange"
              value={startDate}
              minDate={new Date()}
              onChange={(e) => setStartDate(e.target.value)}
            />
            Note:{" "}
            <input
              style={{ borderRadius: "6px" }}
              type="text"
              value={note}
              onChange={(e) => setNote(e.target.value)}
            />
          </Modal.Body>
          <Modal.Footer>
            <Button variant="primary" onClick={handleAddItemsForCards}>
              Submit
            </Button>
          </Modal.Footer>
        </Modal>
      )}

      {/* <DatePicker selected={startDate} onChange={(date) => setStartDate(date)} /> */}
      <div className="container mt-5">
        <div className="row">
          {addItems?.map((item, index) => {
            return (
              <div key={index} className="card-header card bg-light mb-3 card w-25">
                <div className="card-body">
                  <h5 className="card-title">Remaining Days</h5>

                  <div >
                    <div
                      className="card-text"
                      style={{
                        fontWeight: "600",
                        fontSize: "60px",
                        color: "blue",
                      }}
                    >
                      {remainigEventDays(item?.date1)}
                    </div>
                    <div
                      style={{
                        fontWeight: "600",
                        fontSize: "20px",
                        marginBottom: "15px",
                      }}
                    >
                      {item?.note}
                    </div>
                  </div>

                  <button
                    className="btn btn-primary"
                    type="submit"
                    onClick={() => handelRemoveItems(index)}
                  >
                    Cancel
                  </button>
                  <button
                    style={{ marginLeft: "10px" }}
                    className="btn btn-primary"
                    type="submit"
                    onClick={() => {
                      handleShow1();
                      handleEditClick(item);
                    }}
                  >
                    Edit
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

export default App;
